﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_DJRR_1026122
{
    internal class Program
    {
        public static bool Login(string Reslogin, string Respassword)
        {
            string VarPassword;
            VarPassword = Respassword;
            string VarLogin;
            VarLogin = Reslogin;
            bool res = false;
            if (VarLogin == "usuario1" && VarPassword == "asdasd")
            {
                res = true;
            }
            return res;
        }



        static void Main(string[] args)
        {
            string Varlogin1;
            string Varpassword1;
            int cont = 1;
            while (cont < 4)
            {
                Console.WriteLine("Ingrese el usuario: ");
                Varlogin1 = (Console.ReadLine());
                Console.WriteLine("Ingrese la contraseña: ");
                Varpassword1 = (Console.ReadLine());
                if (Login(Varlogin1, Varpassword1) == true)
                {
                    Console.WriteLine("Acceso consedido");
                    cont = 4;
                }
                if (Login(Varlogin1, Varpassword1) == false)
                {
                    Console.WriteLine("Acceso denegado... intente nuevamente ");
                }
                cont++;
            }
            if (cont == 4)
            {
                Console.WriteLine("Acceso bloqueado... limite de intentos sobrepasado ");
            }

            Console.ReadKey();

        }
    }
}
