﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Este es mi segundo programa");
        Console.ReadKey();

        Console.WriteLine("ingrese su Nombre: ");
        string sNombre = Console.ReadLine();
        Console.ReadKey();
        Console.WriteLine("ingrese su Edad: ");
        string sEdad = Console.ReadLine();
        Console.ReadKey();
        Console.WriteLine("ingrese su Carrera: ");
        string sCarrera = Console.ReadLine();
        Console.ReadKey();
        Console.WriteLine("ingrese su Carnet: ");
        string sCarnet = Console.ReadLine();
        Console.ReadKey();
        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carnet: " + sCarnet);

        Console.WriteLine("soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera + ". Mi numero de carnet es; " + sCarnet);
        Console.ReadKey();

    }
 
}
   