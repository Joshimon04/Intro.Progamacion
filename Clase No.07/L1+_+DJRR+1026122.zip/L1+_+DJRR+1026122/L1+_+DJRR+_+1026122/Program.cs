﻿class Program
{
    static void Main(string[] args)
    {
        /* B: MOSTRAR MENSAJE*/
        Console.WriteLine("Hola Mundo soy Diego");
        Console.ReadKey();

        /* D: AGREGAR, EJECUTAR Y DIFERENCIA ENTRE WRITELINE Y WRITE*/
        /* Puedo observar que la diferencia entre Write y WriteLine, es que write nos permite imprimir la informacion sin imprimir la nueva linea que agreguemos
         * todo lo contrario con Writeline el cual se usa para imprmir datos jutno con la impresion de nuevas lineas que deseemos agregar.*/

        /*WRIRELINE*/
        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy Diego");
        /*WRITE*/
        Console.Write("Hola Mundo");
        Console.Write("soy Diego");
        Console.ReadKey();

        /* F: AGREGAR LA INSTRUCCION "INGRESE NOMBRE: "*/

        Console.WriteLine("ingrese su nombre: ");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy " + Nombre);
        Console.ReadKey();
    }
}