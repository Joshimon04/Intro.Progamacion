﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_DJRR_1026122
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese la cantidad de numeros deseada: ");
            int VarN = int.Parse(Console.ReadLine());
            Console.Clear();
            int[] num = new int[VarN];
            for (int i = 0; i < VarN; i++)
            {
                Console.WriteLine("Ingrese número");
                num[i] = int.Parse(Console.ReadLine());
            }
            //A. MOSTRAR LOS NUMEROS INGRESADOS
            Console.Clear();
            Console.WriteLine("Los números ingresados son:");
            for (int i = 0; i < VarN; i++)
            {
                Console.WriteLine(num[i]);

            }
            int SUM = num[0];
            for (int i = 1; i < VarN; i++)
            {
                SUM = num[i] + SUM;
            }
            //B.MOSTRAR LA SUMA DEL ARREGLO
            Console.WriteLine("\nLa suma del vector es: " + SUM + "\n");
            //C.MOESTRAR LA LONGITUD DEL ARREGLO
            Console.WriteLine("La longitud del vector es: " + VarN + "\n");
            //D.ENCONTRAR Y MOSTRAR LA SUMA DE POSICIONES PARES Y LA SUMA DE POSICIONES IMPARES
            int sumaP = num[0];
            for (int i = 1; i < VarN; i++)
            {
                i++;
                if (i < VarN)
                {
                    sumaP = num[i] + sumaP;
                }
            }
            Console.WriteLine("La suma de las posiciones pares es de: " + sumaP + "\n");
            int sumaI = num[1];
            for (int i = 2; i < VarN; i++)
            {
                i++;
                if (i < VarN)
                {
                    sumaI = num[i] + sumaI;
                }
            }
            Console.WriteLine("La suma de las posiciones impares es de: " + sumaI + "\n");
            Console.ReadKey();
        }
    }
}
