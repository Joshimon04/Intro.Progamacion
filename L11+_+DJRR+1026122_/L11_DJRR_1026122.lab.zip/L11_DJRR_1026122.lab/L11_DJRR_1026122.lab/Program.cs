﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_DJRR_1026122.lab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //SECCION A//
            int VarnumA = 0;
            double VarAproA = 0;
            double VarDesaproA = 0;
            double VarNotA = 0;
            double VaroNotA1 = 0;

            Console.WriteLine("Ingrese la cantidad de estudiantes de la seccion A: ");
            VarnumA = int.Parse(Console.ReadLine());

            double[] VarsecA;
            VarsecA = new double[VarnumA];
            for (int i = 0; i < VarnumA; i++)
            {
                Console.WriteLine("Ingresar nota del estudiante: " + (i + 1));
                VarsecA[i] = double.Parse(Console.ReadLine());
                if (VarsecA[i] >= 65)
                {
                    VarAproA++;
                }
                else
                { 
                    VarDesaproA++;
                }
                if (VarsecA[i] > 90)
                {
                    VarNotA++;
                }
                else
                {
                    if (VarsecA[i] < 75)
                    {
                        VaroNotA1++;
                    }
                }
            }


            //SECCION B//
            int VarnumB = 0;
            double VarAproB = 0;
            double VarDesaproB = 0;
            double VarNotB = 0;
            double VaroNotB1 = 0;
            Console.WriteLine("Ingrese la cantidad de estudiantes de la seccion B :");
            VarnumB = int.Parse(Console.ReadLine());

            double[] VarsecB;
            VarsecB = new double[VarnumA];
            for (int i = 0; i < VarnumB; i++)
            {
                Console.WriteLine("Ingresar nota del estudiante: " + (i + 1));
                VarsecB[i] = double.Parse(Console.ReadLine());
                if (VarsecB[i] >= 65)
                {
                    VarAproB++;
                }
                else
                {
                    VarDesaproB++;
                }
                if (VarsecB[i] > 90)
                {
                    VarNotB++;
                }
                else
                {
                    if (VarsecB[i] < 75)
                    {
                        VaroNotB1++;
                    }
                }
            }


            //CALCULO DE PORCENTAJE DE APROVACION(AMBAS SECCIONES)//
            //SEC A//
            double VarAprovporcentA = (VarAproA / VarnumA) * 100;
            Console.WriteLine("El porcentaje de aprovacion de la seccion A es: " + VarAprovporcentA + " %");
            //SEC B//
            double VarAprovporcentB = (VarAproB / VarnumB) * 100;
            Console.WriteLine("El porcentaje de aprovacion de la seccion B es: " + VarAprovporcentB + " %");

            //CALCULO DE PORCENTAJE DE DESAPROVACION(AMBAS SECCIONES)//
            //SEC A//
            double VarDesaprovporcentA = (VarDesaproA / VarnumA) * 100;
            Console.WriteLine("El porcentaje de desaprovacion de la seccion A es: " + VarDesaprovporcentA + " %");
            //SEC B//
            double VarDesaprovporcentB = (VarDesaproB / VarnumB) * 100;
            Console.WriteLine("El porcentaje de desaprovacion de la seccion B es: " + VarDesaprovporcentB + " %");

            //PORCENTAJE DE APROVACION TOTAL//
            double VarAprovporcentAB = ((VarNotA + VarAproB) / (VarnumA + VarnumB)) * 100;
            Console.WriteLine("El procentaje de aprovacion de ambas secciones es: " + VarAprovporcentAB + " %");

            //PORCENTAJE DE DESAPROVACION TOTAL//
            double VarDesaprovporcentAB = ((VarDesaproB + VarDesaproB) / (VarnumA + VarnumB)) * 100;
            Console.WriteLine("El procentaje de desaprovacion de ambas secciones es:" + VarDesaprovporcentAB + " %");



            //CALCULO DE PROMEDIO//
            //SEC A//
            double VarsumA = 0;
            for (int i = 0; i < VarnumA; i++)
            {
                VarsumA = VarsumA + VarsecA[i];
            }
            double VarpromA = VarsumA / VarnumA;
            Console.WriteLine("El promedio de la seccion A es: " + VarpromA);

            //SEC B//
            double VarsumB = 0;
            for (int i = 0; i < VarnumA; i++)
            {
                VarsumB = VarsumB + VarsecA[i];
            }
            double VarpromB = VarsumB / VarnumB;
            Console.WriteLine("El promedio de la seccion B es:" + VarpromB);

            //CALCULO DEL PROMEDIO TOTAL//
            double VarPromTAB = ((VarsumA + VarsumB) / (VarnumA + VarnumB));
            Console.WriteLine("El promedio total de ambas seccion es: " + VarPromTAB);

            //CALCULO DE CANTIDAD DE ESTUDIANTES QUE TENGAN UNA NOTA MAYOR A 90//
            double VarNotmy90 = VarNotA + VarNotB;
            Console.WriteLine("El numero de estuiantes con una nota mayor a 90 es: " + VarNotmy90);

            double VarNotmn75 = VaroNotA1 + VaroNotB1;
            Console.WriteLine("El numero de estuiantes con una nota menor a 75 es: " + VarNotmn75);

            Console.ReadKey();
        }
    }
}
