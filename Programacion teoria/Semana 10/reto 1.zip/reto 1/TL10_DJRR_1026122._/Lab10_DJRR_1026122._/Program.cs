﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Reto 
{
    //EJERCICIO DE PROGRAMACION//
    internal class Program
    {

        static void Main(string[] args)
        {

            Console.WriteLine("RETO 1");
            Console.WriteLine("POR 1000 PUNTOS......");
            Console.WriteLine("RESUELVE PROBLEMA DE RAIZ CUADRADA.... ");
            Console.WriteLine("INGRESE NOMBRE:  ");
            string varnombre = Console.ReadLine(); //aqui definimos una variable de tipo string ya que ibamos a pedir un nombre
            Console.WriteLine("INGRESE NUMERO 1:  ");
            int varnum1 = int.Parse(Console.ReadLine()); //aqui pedimos una variable de tipo int ya que vamos a pedir numeros entreos
            Console.WriteLine("INGRESE NUMERO 2: ");
            int varnum2 = int.Parse(Console.ReadLine()); //aqui pedimos una variable de tipo int ya que vamos a pedir numeros entreos


            double Res_CalcularRaiz = 0; //aqui definimos una variable de tipo double ya que el resultado que mostraremos sera el calculo de la raiz cuadrada

            Calcular objCalculo = new Calcular(varnum1, varnum2);
            objCalculo.CalcularOperacion(ref Res_CalcularRaiz);

            Console.WriteLine(varnombre + ", ESTA CONSULTADO CUAL SERA LAA RAIZ CUADRADA DE LA SUMA DE " + varnum1 + " Y " + varnum2 + " TENIENDO COMO RESULTADO: " + Res_CalcularRaiz);

            Console.ReadKey();
        }
    }

    // esta funcion se encarga de hacer los calculos de una raiz cuadrada de la suma de dos numeros
    class Calcular
    {
        private double VNum1, VNum2;

        public Calcular(double StrNum1, double StrNum2)
        {
            VNum1 = StrNum1;
            VNum2 = StrNum2;
        }

        //definimos una funcion privada de tipo double en donde nos hara el calculo de la suma de los dos numeros y al mismo tiempo sacara su raiz cuadrada
        private double GetRaizCuadrada()
        {

            double Resultado = Math.Sqrt(VNum1 + VNum2);
            return Resultado;
        }
        //aqui definimos una funcion publica para poder hacer el llamado a la funcion privada y asi poder mostrar los resultados cuando esta sea llamada    
        public void CalcularOperacion( ref double unRaiz)
        {

            unRaiz = GetRaizCuadrada();
        }




    }
}
