using System;

class Program
{
    static void Main() {
       
        int numero1;
        int numero2;
        int resultado;
    
    
        Console.WriteLine("Introduzca el primer número");
        numero1 = int.Parse(Console.ReadLine());
        
        Console.WriteLine("Introduzca el segundo número");
        numero2 = int.Parse(Console.ReadLine());
        
        
        Console.WriteLine("Introduzca el reesultado de la suma ");
        resultado = int.Parse(Console.ReadLine());
        
        if (resultado == numero1 + numero2){
            
              Console.WriteLine("Correcto, el resultado es de " + resultado);
        }
        
        
        for(int resulato = numero1 + numero2; resultado != numero1 + numero2; resultado++) {
           
           if (resultado != numero1 + numero2){
            
            Console.WriteLine("El resultado no es correcto, intentelo nuevamente");
             Console.WriteLine("Introduzca el reesultado de la suma ");
             resultado = int.Parse(Console.ReadLine());
             
            
        }
         if (resultado == numero1 + numero2){
            
              Console.WriteLine("Correcto, el resultado es de " + resultado);
         }
         
        }
        
        
    
    }
}
