﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_DJRR_1026122
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] VarEl = new double[4, 5];
            double[,] VarMa = new double[4, 5];
            double[,] VarSum = new double[4, 5];
            double Vara = 0;
            double Varc = 0;
            double Varprom;
            Random Vr = new Random();

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    VarEl[i, j] = Vr.Next(100);
                    Vara = Vara + VarEl[i, j];
                    Varc++;

                }
            }
            Varprom = Vara / Varc;
            Console.WriteLine("El resultado de la suma de la primera matriz es: " + Vara);
            Console.WriteLine("EL promedio resultante de la matriz es: " + Varprom);

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    VarMa[i, j] = Vr.Next(100);


                }

                for (int o = 0; o < 4; o++)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        VarSum[i, j] = VarMa[i, j] + VarEl[i, j];
                        Console.WriteLine("fila  " + i + " columna " + j);
                    }
                }
                Console.ReadKey();


            }


        }
    }
}